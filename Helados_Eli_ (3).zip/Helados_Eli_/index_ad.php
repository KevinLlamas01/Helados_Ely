<?php
include("header_ad.php");
?> 
   
    <a class="a" href="funciones/lista_usuario.php"><div class="lista">Ver los usuarios registrados</div></a>
    <a class="a" href="funciones/lista_usuario_baja.php"><div class="lista">Ver los usuarios dados de baja</div></a>
    <a class="a" href="ver_dom.php"><div class="lista">Ver el domicilio de los usuarios</div></a>
    <a class="a" href="ver_tel.php"><div class="lista">Ver el numero de los usuarios</div></a>
    <a class="a" href="ver_ventas.php"><div class="lista">Ver las ventas realizadas</div></a>
    <a class="a" href="ver_det.php"><div class="lista">Ver los detalles de las ventas</div></a>
    <a class="a" href="ver_pedido.php"><div class="lista">Ver los pedidos de los usuarios</div></a>
    <a class="a" href="ver_reg_toppings.php"><div class="lista">Ver los toppings registrados</div></a>
    <a class="a" href="ver_registro_cat.php"><div class="lista">Ver las categorias registradas</div></a>
    <a class="a" href="ver_registro_prod.php"><div class="lista">Ver los productos registrados</div></a>


    <?php 

include ('footer.php');
 ?>