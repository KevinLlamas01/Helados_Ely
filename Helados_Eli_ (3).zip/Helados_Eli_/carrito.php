<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>carrito</title>
		<link rel="stylesheet" type="text/css" href="css/estilo.css?a=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css?a=1">
  <nav class="navbar" style="background-color: #F7DC6F ;">
  <div class="container-fluid">

<a href="index.php"><img class="logo" src="img/heladeri.png"></a>
<a class="navbar-brand">𝓗𝓮𝓵𝓪𝓭𝓸𝓼  𝓔𝓵𝓲</a>
<a class="navbar-brand">Carrito</a>
<a class="navbar-brand" href="sobre_nos.html">𝓢𝓸𝓫𝓻𝓮 𝓷𝓸𝓼𝓸𝓽𝓻𝓸𝓼</a>
</nav>
</div>
</head>

<body style="background-color: #A3E4D7;">





</body>



<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<footer style="background-color: #F7DC6F; margin-bottom: -12%;" >
  <ul>
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-md-6">
        <h6 class="text-muted lead">CONTACTO:</h6>
        <h6 class="text-muted"> El Rosario, Sinaloa<br>
          Teléfonos: 6692551445.<br>
        </h6>
      </div>
      <div class="col-xs-12 col-md-6">
        <div class="pull-right">
          <h6 class="text-muted lead">ENCUENTRANOS EN REDES SOCIALES</h6>
          <div class="redes-footer">
            <a href="https://www.facebook.com/rubeneduardo.perazaesquer"/><img src=img/fb.png style="width:50px; height:50px;"></a>
              <a href="https://www.facebook.com/rubeneduardo.perazaesquer"/><img src=img/ig.png style="width:50px; height:50px;"></a>

          </div>
        </div>
        <div class="row"> <p class="text-muted small text-right">Rubén Eduardo Peraza Esquer<br> Todos los derechos reservados 2022.</p></div>
        
      </div>
    </div>  
  </div>
</ul>
  </footer>
</html>


