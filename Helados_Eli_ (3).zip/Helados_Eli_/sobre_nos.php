<?php 
include ('header.php');
 ?>

<style type="text/css">
  .card-group{
    display: inline-block;
    margin-left: 1%;
  }
</style>
<br><br>
<body style="background-color: #A3E4D7;">

<div class="card-group" style="width:425px; height: 300px;">
  <div class="card" style="width: ; background-color: #a5d6a7;">
    <img src="" class="card-img-top" style="width:250px; height:150px; " alt="...">
    <div class="card-body">
      <h5 class="card-title">David Prieto.</h5>
      <h5 class="card-title">Joel Medicina.</h5>
      <p class="card-text">Encargados del back end y Apis</p>
     
    </div>
  </div>
</div>
    <div class="card-group" style="width:425px; height: 300px;">
  <div class="card" style="width: ; background-color: #ef9a9a;">
    <img src="img/" class="card-img-top" style="width:250px; height:150px; " alt="...">
    <div class="card-body">
      <h5 class="card-title">Ruben Eduardo .</h5>
       <h5 class="card-title">Edwin no se que.</h5>
      <p class="card-text">Encargados del diseño y seguridad</p>
    </div>
  </div>
</div>

 <div class="card-group" style="width:425px; height: 300px;">
  <div class="card" style="width: ; background-color: #4db6ac;">
    <img src="" class="card-img-top" style="width:250px; height:150px; " alt="...">
    <div class="card-body">
      <h5 class="card-title">Kevin Llamas</h5>
      <h5 class="card-title">Nicolas Catillo</h5>
      <p class="card-text">Encargados del carrito y base de datos</p>
      
    </div>
  </div>
</div>
<br><br><br><br><br><br><br><br>
<center>
<h2>Quienes somos?</h2><br>
<div class="col-6">
<img class="sn" src="img/h1.jpg">
<br><br>
<h6>Helados  Eli:<br>

Helados Eli nace hace más de 10 años en Escuinapa,Sinaloa gracias a una receta casera para preparar nieve de garrafa.
Donde la actual sucursal en existencia se creo en 2012.
Fue entonces que en 2022 se les ocurrió para mejorar el modelo de negocio crear una app web para aumentar sus ventas en la ciudad, de la mano de los alumnos de desarrolladores de la UTEsc Nicolás Romero Castillo, Kevin Omar Llamas López, Edwin Diaz Ochoa,Rubén Eduardo Pedraza Esquer, David Alberto Hernández Moreno y Jose Joel Medina, y con ayuda de la docente Elizabeth Carrillo.</h6>
</div>
</center>

<br><br><br><br><br><br><br><br>
<center>
<h2>Donde nos encontramos?</h2><br>
<div class="col-6">
<img class="sn" src="img/h1.jpg">
<br><br>
<h6>Establecimiento:<br>

Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</h6>
</div>
</center>
</body>
</html>

<?php 

include ('footer.php');
 ?>