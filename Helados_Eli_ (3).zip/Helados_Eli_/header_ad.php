<body style="background-color: #A3E4D7;">

<!DOCTYPE html>
<html>
<!--Navegador-->
<head>
  <script type="text/javascript" src="js/bootstrap.js"></script>
	<title>ADMIN</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css?a=6">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css?a=3">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.3/font/bootstrap-icons.css">
  <nav class="navbar" style="background-color: #F7DC6F ;">
  <div class="container-fluid">
<a href="index.php"><img class="logo" src="img/heladeri.png"></a>
<a class="navbar-brand" href="index_ad.php">Inicio</a>
<a class="navbar-brand" href="formulario_registro_categoria.php">Registrar categorias</a>
<a class="navbar-brand" href="formulario_registro_helados.php">Registrar Productos</a>
<a class="navbar-brand" href="formulario_toppings.php">Registrar toppings</a>
</nav>
</head>
</div>

