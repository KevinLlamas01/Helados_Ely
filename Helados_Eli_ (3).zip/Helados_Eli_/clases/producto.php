<?php 

class producto
{
	
	function __construct()
	{
		require_once("Conexion.php");
		$this->conexion = new Conexion();
	}
	function insertar($nom,$precio,$desc,$stock,$foto, $fk_categoria){
		$consulta="INSERT INTO producto(idproducto, nombre, precio, descripcion, stock,
		 foto, estatus, fk_categoria_producto) VALUES 
		(null, '{$nom}', '{$precio}', '{$desc}', '{$stock}', '{$foto}', 1, '{$fk_categoria}')";
		$resultado=$this->conexion->query($consulta);
		return $resultado;
	}
	function mostrar(){
		$consulta="SELECT * FROM  producto";
		$resultado=$this->conexion->query($consulta);
		return $resultado;
	}

	function baja($idproducto){
		$consulta="UPDATE producto SET estatus=0 WHERE idproducto='{$idproducto}'";
		$resultado=$this->conexion->query($consulta);
		return $resultado;  
	  }
	  function actualizar($idproducto,$nombre,$precio,$desc,$stock,$foto){
		$consulta="UPDATE producto SET nombre='{$nombre}', precio='{$precio}', descripcion='{$desc}', stock='{$stock}', foto='{$foto}' WHERE idproducto='{$idproducto}'";
		$resultado=$this->conexion->query($consulta);
		return $resultado;
	  }
	
	  function alta($idproducto){
		$consulta="UPDATE producto SET estatus=1 WHERE idproducto='{$idproducto}'";
		$resultado=$this->conexion->query($consulta);
		return $resultado;  
	  }

	  function mostrarPorId($idproducto){
		$consulta="SELECT * FROM producto WHERE idproducto='{$idproducto}' ";
		$respuesta=$this->conexion->query($consulta);
		return $respuesta;
	 }
	}
 ?>