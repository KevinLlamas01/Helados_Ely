<?php

class venta
{
 function __construct()
 {
   require_once("Conexion.php");
   $this->conexion = new Conexion();
 }


 function insertar($fecha,$subtotal,$total,$iva,$fk_metodo_pago){
   $consulta="INSERT INTO venta(idventa,fecha,subtotal,total,iva,fk_usuario,fk_metodo_pago,estatus)VALUES(null,'{$fecha}','{$subtotal}','{$total}','{$iva}',null,'{$metodo_pago}',1)";
   $resultado=$this->conexion ->query ($consulta);
      return $resultado;
 }
 function mostrar(){

    $consulta="SELECT * FROM  usuario u INNER JOIN carrito c ON  u.idusuario=c.fk_usuario INNER JOIN  venta v ON v.fk_carrito= c.idcarrito";
    $resultado=$this->conexion ->query ($consulta);
    return $resultado;
  }

  function baja ($idventa){
    $consulta="UPDATE venta SET estatus=0 WHERE idventa='{$idventa}'";
    $resultado=$this->conexion->query($consulta);
    return $resultado;  
  }

  function actualizar($idventa, $fecha, $subtotal, $total, $iva,$fk_metodo_pago,$fk_carrito){
    $consulta="UPDATE venta SET fecha='{$fecha}', subtotal='{$subtotal}', total='{$total}', iva='{$iva}',fk_metodo_pago='{$fk_metodo_pago}',fk_carrito='{$fk_carrito}' WHERE idventa='{$idventa}' ";
    $resultado=$this->conexion->query($consulta);
    return $resultado;
  }
}
?>