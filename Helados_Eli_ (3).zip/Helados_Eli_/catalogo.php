<?php session_start(); 

if (!isset($_SESSION['idusuario'])){

    echo "<meta http-equiv='REFRESH' content='0; url=inicio_sesion.php'> <script> alert('Favor de iniciar sesion para entrar aqui') </script>";

}
?>  


<?php
require 'config/config.php';
require 'config/conexion.php';
$db= new Database();
$con=$db->conectar();

$sql=$con->prepare("SELECT idproducto, nombre, precio FROM producto WHERE estatus=1");
$sql->execute();
$resultado=$sql->fetchAll(PDO::FETCH_ASSOC);

session_destroy();

//print_r($_SESSION);
?>

<?php include('header.php'); ?>

    <!--Contenido-->
    <main>
        <div class="container">
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                <?php foreach ($resultado as $row) { ?>
                <div class="col">
                    <div class="card shadow-sm">
                        <?php 
                            $id=$row['idproducto'];
                            $imagen="img/producto/" . $id . "/principal.jpg";

                            if (!file_exists($imagen)){
                                $imagen="img/nofoto.png"; 
                            }

                         ?>
                        <img src="<?php echo $imagen; ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $row['nombre']; ?></h5>
                            <p class="card-text"><?php echo $row['precio']; ?></p>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    <a href="detalles.php?id=<?php echo $row['idproducto']; ?>&token=<?php echo hash_hmac('sha1', $row['idproducto'], KEY_TOKEN); ?>" class="btn btn-primary">Detalles</a>
                                </div>
                                <button class="btn btn-outline-primary" type="button" onclick="addProducto(<?php echo $row['idproducto']; ?>, '<?php echo hash_hmac('sha1', $row['idproducto'], KEY_TOKEN); ?>')">Agregar al carrito</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } ?>
            </div>
        </div>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script>
        function addProducto(id, token){
            let url = 'clases/carrito.php'
            let formData= new FormData()
            formData.append('id', id)
            formData.append('token', token)

            fetch(url, {
                method: 'POST',
                body: formData,
                mode: 'cors'
            }).then(response => response.json())
            .then(data=>{
                if(data.ok){
                    let elemento= document.getElementById("num_cart")
                    elemento.innerHTML = data.numero
                }
            })

        }
    </script>
</body>
</html>
<?php include('footer.php'); ?>
