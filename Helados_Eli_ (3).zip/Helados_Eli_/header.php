<!--Inicio del header-->


<?php session_start();
//if (!isset($_SESSION['idusuario'])) {
   //header("location: inicio_sesion.php");

  //}
 ?>
 <body style="background-color: #A3E4D7;">

<!DOCTYPE html>
<html>
<!--Navegador-->
<head>
  <script type="text/javascript" src="js/bootstrap.js"></script>
	<title>INDEX1</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css?a=3">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css?a=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.3/font/bootstrap-icons.css">
  <nav class="navbar" style="background-color: #F7DC6F ;">
  <div class="container-fluid">

<a href="index.php"><img class="logo" src="img/heladeri.png"></a>
<a class="navbar-brand" href="index.php">𝓗𝓮𝓵𝓪𝓭𝓸𝓼  𝓔𝓵𝓲</a>
<a class="navbar-brand" href="sobre_nos.php">𝓢𝓸𝓫𝓻𝓮 𝓷𝓸𝓼𝓸𝓽𝓻𝓸𝓼</a>
<a class="navbar-brand" href="registro.php">𝓡𝓮𝓰𝓲𝓼𝓽𝓻𝓸</a>
<a class="navbar-brand" href="catalogo.php">Catalogo</a>




  <?php 
  if (isset($_SESSION['idusuario'])){
    if  ($_SESSION['tipo']==2){ 
      echo '<a class="navbar-brand" href="index_ad.php"> Admin </a> ';
    }
  }else {
    echo '<a class="navbar-brand" href="inicio_sesion.php"> Inicio de sesion </a>';
  }
   ?>


<a class="navbar-brand"  href="funciones/cerrar_sesion.php"><?php  if (isset($_SESSION['idusuario'])){   echo $_SESSION['nombre'];}  ?></a>

</nav>

</head>