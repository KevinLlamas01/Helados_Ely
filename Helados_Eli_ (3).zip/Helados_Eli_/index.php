<?php 
include ('header.php');
 ?>

<style type="text/css">
  .card-group{
    display: inline-block;
    margin-left: 1%;
  }
</style>
<!--Cuerpo (carrucel)-->
<br>

  <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="img/h1.jpg" width="500" height="500px" class="d-block w-100" alt="">  
      </div>
      <div class="carousel-item">
        <img src="img/h2.jpg" width="500px" height="500px" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="img/h3.jpg" width="500px" height="500px" class="d-block w-100" alt="...">
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
  <!--Fin del carrusel-->

<br><br><br><br><br><br><br>


    <div class="card-group" style="width:425px; height: 300px;">
  <div class="card" style="width: ; background-color: #0BE3A5;">
    <img src="img/p1.jpeg" class="card-img-top" style="width:250px; height:150px; " alt="...">
    <div class="card-body">
      <h5 class="card-title">Nieves populares</h5>
      <p class="card-text">Es esto esto y esto bla blabbalbalbalablabla</p>
      <p class="card-text"><small class="text-muted">Precio "Ponganlo"</small></p>
      <a href="menu.php"> <button type="button" class="btn btn-outline-secondary" style="background-color:#F3FC64 ;">Menu</button></a>
    </div>
  </div>
</div>
    <div class="card-group" style="width:425px; height: 300px;">
  <div class="card" style="width: ; background-color: #0BE3A5;">
    <img src="img/p1.jpeg" class="card-img-top" style="width:250px; height:150px; " alt="...">
    <div class="card-body">
      <h5 class="card-title">Paletas populares</h5>
      <p class="card-text">Es esto esto y esto bla blabbalbalbalablabla</p>
      <p class="card-text"><small class="text-muted">Precio "Ponganlo"</small></p>
      <a href="menu.php"> <button type="button" class="btn btn-outline-secondary" style="background-color:#F3FC64 ;">Menu</button></a>
    </div>
  </div>
</div>

 <div class="card-group" style="width:425px; height: 300px;">
  <div class="card" style="width: ; background-color: #0BE3A5;">
    <img src="img/p1.jpeg" class="card-img-top" style="width:250px; height:150px; " alt="...">
    <div class="card-body">
      <h5 class="card-title">Aguas populares</h5>
      <p class="card-text">Es esto esto y esto bla blabbalbalbalablabla</p>
      <p class="card-text"><small class="text-muted">Precio "Ponganlo"</small></p>
      <a href="menu.php"> <button type="button" class="btn btn-outline-secondary" style="background-color:#F3FC64 ;">Menu</button></a>
    </div>
  </div>
</div>



<?php 

include ('footer.php');
 ?>
</body>





